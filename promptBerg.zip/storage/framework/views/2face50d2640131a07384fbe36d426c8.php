<?php $__env->startSection('content'); ?>
    <div class="seller-details">
        <div class="seller-details__thumb">
            <img src="<?php echo e(getImage(getFilePath('userCover') . '/' . $user->coverImage, cover: true)); ?>" alt="image" class="fit-image">
        </div>
        <div class="seller-wrapper pb-70">
            <div class="container">
                <div class="seller-profile d-flex justify-content-between">
                    <div class="seller-profile__thumb">
                        <img src="<?php echo e(getImage(getFilePath('userProfile') . '/' . $user->image, avatar: true)); ?>" alt="image" class="fit-image">
                    </div>

                    <div class="mt-4">
                        <button type="button" class="btn <?php if(auth()->id() == $user->id): ?> disabled <?php endif; ?> <?php echo e($isFollowing ? 'btn--success' : 'btn--black'); ?> <?php if(auth()->guard()->guest()): ?> loginButton <?php else: ?> btn-follow <?php endif; ?>" data-id="<?php echo e($user->id); ?>">
                            <?php echo e($isFollowing ? __('Following') : __('Follow')); ?> <i class="fa-solid <?php echo e($isFollowing ? 'fa-user-check' : 'fa-user-plus'); ?>"></i>
                        </button>
                    </div>

                </div>
                <div class="seller-details__content">
                    <span class="seller-details__name mb-0"> <?php echo e('@' . $user->username); ?></span>
                    <?php if($user->description): ?>
                        <p class="desc"><?php echo e(__($user->description)); ?></p>
                    <?php endif; ?>
                    <ul class="popular-list d-flex gap-3 flex-wrap">
                        <li class="popular-list__item">
                            <span class="badge-tag style-two">
                                <i class="fa-solid fa-eye"></i>
                                <span class="text-white">
                                    <?php echo e(formatProfileViewCount($user->profile_view)); ?>

                                </span>
                            </span>
                        </li>
                        <li class="popular-list__item">
                            <span class="badge-tag style-two">
                                <span class="text-white"><?php echo e($user->prompts->count()); ?> <?php echo app('translator')->get('Prompts'); ?></span>
                            </span>
                        </li>
                    </ul>

                    <ul class="seller-activities d-flex gap-3 flex-wrap mt-2">
                        <li>
                            <strong class="text-white"> <?php echo e($user->follows->count()); ?></strong> <?php echo app('translator')->get('Following'); ?>
                        </li>
                        <li>
                            <strong class="text-white"><?php echo e($user->followers->count()); ?></strong> <?php echo app('translator')->get('Followers'); ?>
                        </li>
                    </ul>

                </div>
            </div>
        </div>
    </div>

    <?php if(!blank($prompts)): ?>
        <section class="trending-area pt-60 pb-60">
            <div class="container">
                <div class="section-common-header d-flex flex-wrap justify-content-between gap-3 align-items-center">
                    <h4 class="title"><?php echo app('translator')->get('Prompts'); ?></h4>

                    <div class="form-group  mb-0">
                        <div class="border-gradient subscribe-input search-form-wrapper w-100">
                            <form method="GET">
                                <input type="text" name="search" class="form-control form--control border-gradient w-100" placeholder="<?php echo app('translator')->get('Search'); ?>..." autocomplete="off" value="<?php echo e(request()->search); ?>">
                                <button class="search-form__btn"><i class="fa-solid fa-search"></i></button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="row gy-4">
                    <?php echo $__env->make($activeTemplate . 'partials.trending_prompt', [
                        'prompts' => $prompts,
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="mt-5">
                    <?php echo e(paginateLinks($prompts)); ?>

                </div>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function($) {
            "use strict";
            $(document).ready(function() {
                $('.btn-follow').on('click', function() {
                    var button = $(this);
                    var followedUserId = button.data('id');

                    $.ajax({
                        url: '<?php echo e(route('user.follow')); ?>',
                        method: 'POST',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            followed_user_id: followedUserId
                        },
                        success: function(response) {
                            if (response.success) {
                                if (response.message === 'Followed successfully') {

                                    button.find('i').removeClass('fa-user-plus').addClass(
                                        'fa-user-check');
                                    button.contents().filter(function() {
                                        return this.nodeType === 3;
                                    }).first().replaceWith('<?php echo app('translator')->get('Following'); ?> ');

                                    button.removeClass('btn--black').addClass(
                                        'btn--success');
                                } else {

                                    button.find('i').removeClass('fa-user-check').addClass(
                                        'fa-user-plus');
                                    button.contents().filter(function() {
                                        return this.nodeType === 3;
                                    }).first().replaceWith('<?php echo app('translator')->get('Follow'); ?> ');

                                    button.removeClass('btn--success').addClass(
                                        'btn--black');
                                }
                                notify('success', response.message);
                            }
                        },
                        error: function(xhr, status, error) {
                            let errorMessage = xhr.responseJSON ? xhr.responseJSON.message :
                                'An error occurred';
                            notify('error', errorMessage);
                        }
                    });
                });
            });
        })(jQuery)
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .section-common-header {
            padding-bottom: 20px;
            margin-bottom: 24px;
            border-bottom: 1px solid hsl(var(--border-color));
            font-family: var(--body-font);
            font-weight: 500;
            font-size: 1.125rem;
        }

        .section-common-header .title {
            padding-bottom: unset;
            margin-bottom: unset;
            border-bottom: unset;
        }

        @media screen and (max-width: 767px) {
            .pagination {
                margin-top: 0;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_8_2\htdocs\PromptLab\Files\core\resources\views/templates/basic/prompt/profile.blade.php ENDPATH**/ ?>