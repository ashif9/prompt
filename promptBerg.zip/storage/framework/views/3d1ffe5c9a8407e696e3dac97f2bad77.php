<?php
    $content = getContent('login.content', true);
?>


<?php $__env->startSection('panel'); ?>
    <section class="account">
        <div class="account__inner  flex-wrap">
            <div class="account-left  flex-wrap">
                <div class="account-left__thumb">
                    <img src="<?php echo e(frontendImage('login', @$content->data_values->image, '1000x950')); ?>" alt="image" class="fit-image">
                </div>
            </div>
            <div class="account-right">
                <div class="account-content">
                    <div class="account-form">
                        <div class="account-form_content text-center">
                            <div class="logo mb-4">
                                <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(sitelogo()); ?>" alt="logo"></a>
                            </div>
                            <h4 class="account-form__title">
                                <?php echo e(__($content->data_values->heading)); ?>

                            </h4>
                            <p class="account-form__desc"><?php echo e(__($content->data_values->subheading)); ?></p>
                        </div>
                        <form action="<?php echo e(route('user.login')); ?>" method="POST" class="account-form verify-gcaptcha">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="form--label" for="username"><?php echo app('translator')->get('Username'); ?></label>
                                <input type="text" class="form--control" id="username" name="username" value="<?php echo e(old('username')); ?>" placeholder="<?php echo app('translator')->get('Enter username'); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form--label" for="your-password"><?php echo app('translator')->get('Password'); ?></label>
                                <div class="position-relative">
                                    <input type="password" name="password" id="your-password" placeholder="<?php echo app('translator')->get('Enter Password'); ?>" class="form--control" value="<?php echo e(old('password')); ?>">
                                    <span class="password-show-hide fas toggle-password fa-eye-slash" id="#your-password"></span>
                                </div>
                            </div>
                            <div class="form-group d-flex flex-wrap justify-content-between">
                                <div class="form--check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember">
                                    <label class="form-check-label" for="remember"><?php echo app('translator')->get('Remember Me'); ?></label>
                                </div>
                                <div class="have-account text-center">
                                    <a href="<?php echo e(route('user.password.request')); ?>" class="forgot-text text-color"><?php echo app('translator')->get('Forgot password?'); ?></a>
                                </div>
                            </div>

                            <?php if (isset($component)) { $__componentOriginalff0a9fdc5428085522b49c68070c11d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff0a9fdc5428085522b49c68070c11d6 = $attributes; } ?>
<?php $component = App\View\Components\Captcha::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('captcha'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Captcha::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff0a9fdc5428085522b49c68070c11d6)): ?>
<?php $attributes = $__attributesOriginalff0a9fdc5428085522b49c68070c11d6; ?>
<?php unset($__attributesOriginalff0a9fdc5428085522b49c68070c11d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff0a9fdc5428085522b49c68070c11d6)): ?>
<?php $component = $__componentOriginalff0a9fdc5428085522b49c68070c11d6; ?>
<?php unset($__componentOriginalff0a9fdc5428085522b49c68070c11d6); ?>
<?php endif; ?>

                            <div class="form-group">
                                <button type="submit" id="recaptcha" class="btn btn--base h-48 w-100"><?php echo app('translator')->get('Submit'); ?></button>
                            </div>

                            <?php echo $__env->make($activeTemplate . 'partials.social_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <div class="form-group mt-3">
                                <div class="have-account text-center">
                                    <p class="have-account__text fs-16"><?php echo app('translator')->get('Don\'t have an account?'); ?>
                                        <a href="<?php echo e(route('user.register')); ?>" class="have-account__link text--gradient"><?php echo app('translator')->get('Create new account'); ?></a>
                                    </p>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_8_2\htdocs\PromptLab\Files\core\resources\views/templates/basic/user/auth/login.blade.php ENDPATH**/ ?>