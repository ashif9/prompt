<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="table-responsive--sm table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('Prompt Title'); ?></th>
                                    <th><?php echo app('translator')->get('Owner'); ?></th>
                                    <th><?php echo app('translator')->get('Sale'); ?></th>
                                    <th><?php echo app('translator')->get('View'); ?></th>
                                    <th><?php echo app('translator')->get('Category'); ?></th>
                                    <th><?php echo app('translator')->get('AI Tool'); ?></th>
                                    <th><?php echo app('translator')->get('Status'); ?></th>
                                    <th><?php echo app('translator')->get('Is Featured'); ?></th>
                                    <th><?php echo app('translator')->get('Action'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $prompts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prompt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="text-start">
                                            <div class="d-flex flex-wrap justify-content-end justify-content-lg-start">
                                                <span class="avatar avatar--xs me-2">
                                                    <img
                                                         src="<?php echo e(getImage(getFilePath('prompt') . '/' . 'thumb_' . @$prompt->image)); ?>">
                                                </span>
                                                <span>
                                                    <?php echo e(strLimit(__($prompt->title), 25)); ?>


                                                </span>
                                            </div>
                                        </td>
                                        <td><?php echo e(__($prompt->user->fullname)); ?> <br>
                                            <span class="small">
                                                <a href="<?php echo e(route('admin.users.detail', $prompt->user->id)); ?>"><span>@</span><?php echo e($prompt->user->username); ?></a>
                                            </span>
                                        </td>

                                        <td>
                                            <?php echo e($prompt->sales_count); ?>

                                        </td>

                                        <td><?php echo e($prompt->views); ?></td>
                                        <td><?php echo e(__($prompt->category->name?? '')); ?></td>

                                        <td>
                                            <?php echo e(__($prompt->tool->name)); ?> <?php if($prompt->tool_version_id): ?>(<?php echo e(__($prompt->toolVersion->name?? '')); ?>) <?php endif; ?>
                                        </td>

                                        <td><?php echo $prompt->promptStatusBadge; ?></td>

                                        <td>
                                            <?php if($prompt->is_featured == Status::PROMPT_FEATURED): ?>
                                                <span class="badge badge--info"> <?php echo app('translator')->get('Yes'); ?></span>
                                            <?php else: ?>
                                                <span class="badge badge--warning"> <?php echo app('translator')->get('No'); ?></span>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <div class="button--group">
                                                <a class="btn btn-sm btn-outline--primary" href="<?php echo e(route('admin.prompt.details', $prompt->slug)); ?>">
                                                    <i class="las la-desktop"></i> <?php echo app('translator')->get('Details'); ?>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
                <?php if($prompts->hasPages()): ?>
                    <div class="card-footer py-4">
                        <?php echo e(paginateLinks($prompts)); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <?php if (isset($component)) { $__componentOriginale48b4598ffc2f41a085f001458a956d1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale48b4598ffc2f41a085f001458a956d1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-form','data' => ['promptIsPublished' => 'yes','placeholder' => 'search...']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['promptIsPublished' => 'yes','placeholder' => 'search...']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale48b4598ffc2f41a085f001458a956d1)): ?>
<?php $attributes = $__attributesOriginale48b4598ffc2f41a085f001458a956d1; ?>
<?php unset($__attributesOriginale48b4598ffc2f41a085f001458a956d1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale48b4598ffc2f41a085f001458a956d1)): ?>
<?php $component = $__componentOriginale48b4598ffc2f41a085f001458a956d1; ?>
<?php unset($__componentOriginale48b4598ffc2f41a085f001458a956d1); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $('select').on('change', function() {
            let form = $('.filter');
            form.submit();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_8_2\htdocs\PromptLab\Files\core\resources\views/admin/prompt/index.blade.php ENDPATH**/ ?>