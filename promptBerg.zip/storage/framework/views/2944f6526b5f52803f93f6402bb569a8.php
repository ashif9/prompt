<?php $__env->startSection('content'); ?>

    <div class="container pb-60">
        <div class="row gy-4">
            <div class="col-lg-6">
                <div class="prompt-details__thumb pb-2">

                    <div class="prompt-details__item">
                        <img src="<?php echo e(getImage(getFilePath('prompt') . '/' . @$prompt->image)); ?>" alt="img">
                    </div>
                    <?php $__currentLoopData = $prompt->promptImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="prompt-details__item">
                            <img src="<?php echo e(getImage(getFilePath('prompt') . '/' . @$image->image)); ?>" alt="img">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php if(!blank($prompt->promptImages)): ?>
                    <div class="prompt-details__gallery">
                        <?php $__currentLoopData = $allImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="prompt-gallery__item">
                                <img src="<?php echo e(getImage(getFilePath('prompt') . '/' . 'thumb_' . @$image)); ?>" alt="img">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-lg-6">
                <div class="prompt-details-content">
                    <div class="d-flex gap-2 justify-content-between">
                        <h2 class="title">
                            <?php echo e(__($prompt->title)); ?>

                        </h2>
                        <div>
                            <button type="button" class="wishlist-btn <?php if(auth()->guard()->guest()): ?> loginButton <?php else: ?> favorite-btn <?php endif; ?>  <?php if($isFavorite): ?> text-danger <?php endif; ?>" data-id="<?php echo e($prompt->id); ?>"><i class="fa-solid fa-heart"></i></button>
                        </div>
                    </div>
                    <div class="list list--row rating-list">
                        <span class="rating-list__icon rating-list__icon-active">
                            <?php
                                $avgRating = $prompt->getAvgRating();
                            ?>
                            <?php echo displayRating($avgRating) ?>
                        </span>

                        (<?php echo e(getAmount($avgRating)); ?> <?php echo app('translator')->get('stars'); ?>) <i class="fas fa-circle fs-4 mx-2"></i> <?php echo e($prompt->reviews_count); ?>


                        <span><?php echo app('translator')->get('reviews'); ?></span>
                    </div>

                    <ul class="prompt-info">
                        <li>
                            <span class="badge-tag style-two">
                                <i class="fa-solid fa-wand-sparkles"></i>
                                <span class="text-white"><?php echo e(__($prompt->tool->name)); ?></span>
                            </span>
                        </li>
                        <?php if($prompt->tool_version_id): ?>
                            <li>
                                <span class="badge-tag style-two">
                                    <span class="text-white"><?php echo e(__($prompt->toolVersion->name)); ?></span>
                                </span>
                            </li>
                        <?php endif; ?>
                        <li>
                            <span class="featurs"><?php echo app('translator')->get('Created'); ?>: <?php echo e(diffForHumans($prompt->created_at)); ?></span>
                        </li>
                    </ul>

                    <div class="prompt-interaction">
                        <span class="interaction-tag">
                            <i class="fa-solid fa-heart"></i> <?php echo e(__($prompt->favorites_count)); ?>

                        </span>
                        <span class="interaction-tag">
                            <i class="fa-solid fa-eye"></i> <?php echo e(__($prompt->views)); ?>

                        </span>
                    </div>

                    <div class="creator-profile py-4">
                        <p class="mb-2"><?php echo app('translator')->get('Creator'); ?></p>
                        <div class="d-flex gap-3 align-items-center">
                            <div class="thumb">
                                <img src="<?php echo e(getImage(getFilePath('userProfile') . '/' . $prompt->user->image, avatar: true)); ?>" alt="img">
                                <img class="badge-img" src="<?php echo e(asset($activeTemplateTrue . 'images/thumbs/badge.svg')); ?>" alt="img">
                            </div>
                            <div>
                                <span class="badge-tag style-two">
                                    <a href="<?php echo e(route('seller.profile', $prompt->user->username)); ?>"><span class="text-white fs-14"> <?php echo e('@'. $prompt->user->username); ?></span></a>
                                </span>
                            </div>
                        </div>
                    </div>
                    <p class="desc max-width-425">
                        <?php echo $shortDescription ?>
                        <?php if(strlen($description) > $limit): ?>
                            <span class="moretext">
                                <?php echo substr($description, strlen($shortDescription)) ?>
                            </span> <a class="moreless-button text-white" href="#"><?php echo app('translator')->get('More....'); ?></a>
                        <?php endif; ?>
                    </p>
                    <h4 class="price mb-0"><?php echo e(showAmount($prompt->price)); ?></h4>
                    <div class="prompt-btn d-flex gap-3 mb-4 flex-wrap">
                        <?php if(auth()->guard()->check()): ?>
                            <button class="btn button btn--base btn--lg btn-add-to-cart" data-prompt-id="<?php echo e($prompt->id); ?>"><i class="fa-solid fa-cart-shopping"></i>
                                <?php echo app('translator')->get('Add To Cart'); ?></button>
                        <?php else: ?>
                            <button class="btn button btn--base btn--lg loginButton"><i class="fa-solid fa-cart-shopping"></i>
                                <?php echo app('translator')->get('Add To Cart'); ?></button>
                        <?php endif; ?>
                    </div>

                </div>
            </div>

            <div class="col-lg-6">
                <!-- Comments Start -->
                <div class="review-prompt">
                    <?php if(!blank($reviews)): ?>
                        <div class="review-prompt-header">
                            <h6 class="review-prompt-title">
                                <?php echo app('translator')->get('Prompt Review'); ?> <i class="fa-solid fa-angle-up"></i>
                            </h6>
                        </div>
                    <?php endif; ?>
                    <div class="review-prompt__content">
                        <?php if(!blank($reviews)): ?>
                            <div class="review-list">
                                <p class="desc"><?php echo app('translator')->get('See what others are saying about this prompt'); ?></p>

                                <ul class="comment-list" id="comment-list">
                                    <?php echo $__env->make($activeTemplate . 'prompt.review', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if($reviews->nextPageUrl()): ?>
                            <div class="load-more text-white">
                                <button class="btn--base btn btn--sm "><?php echo app('translator')->get('LOAD MORE'); ?></button>
                            </div>
                        <?php endif; ?>
                        <!-- Comments End -->

                        <!-- Comments Form Start -->
                        <?php if($hasPurchased && !$userReview): ?>
                            <div class="pt-5" id="comment-box">
                                <h4><?php echo app('translator')->get('Write your review'); ?></h4>
                                <form action="<?php echo e(route('user.prompt.review', $prompt->slug)); ?>" method="POST" autocomplete="off">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="rating"><?php echo app('translator')->get('Rating'); ?></label>
                                                <div class="rating">
                                                    <div class="rating-form-group">
                                                        <label class="star-label">
                                                            <input name="rating" type="radio" value="1" />
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                        </label>
                                                        <label class="star-label">
                                                            <input name="rating" type="radio" value="2" />
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                        </label>
                                                        <label class="star-label">
                                                            <input name="rating" type="radio" value="3" />
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                        </label>
                                                        <label class="star-label">
                                                            <input name="rating" type="radio" value="4" />
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                        </label>
                                                        <label class="star-label">
                                                            <input name="rating" type="radio" value="5" />
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                            <span class="icon fs-26"><i class="las la-star"></i></span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="comment"><?php echo app('translator')->get('Write your opinion'); ?></label>
                                                <textarea name="review" class="mt-2 form--control" required></textarea>
                                            </div>
                                        </div>

                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-outline--base btn--lg"><?php echo app('translator')->get('Submit Review'); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        <?php endif; ?>
                        <!-- Comment Form End -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if(!blank($relatedPrompts)): ?>
        <section class="features-area pt-60 pb-60">
            <div class="container">
                <div class="section-heading style-left d-flex flex-wrap justify-content-between gap-2">
                    <div class="section-heading__left">
                        <h2 class="section-heading__title"><?php echo app('translator')->get('Similar Prompts'); ?></h2>
                    </div>
                    <?php if($relatedPromptsCount > 6): ?>
                        <div class="section-heading__right">
                            <a href="<?php echo e(route('prompt.similar', $prompt->slug)); ?>" class="btn btn-outline--base"><?php echo app('translator')->get('View all'); ?></a>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="row gy-4">
                    <?php echo $__env->make($activeTemplate . 'partials.related_prompt', ['prompts' => $relatedPrompts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link href="<?php echo e(asset($activeTemplateTrue . 'css/slick.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset($activeTemplateTrue . 'js/slick.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        (function($) {
            "use strict";

            $('.prompt-details__thumb').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: false,
                dots: false,
                fade: true,
                asNavFor: '.prompt-details__gallery',
                prevArrow: '<button type="button" class="slick-prev gig-details-thumb-arrow"><i class="las la-long-arrow-alt-left"></i></button>',
                nextArrow: '<button type="button" class="slick-next gig-details-thumb-arrow"><i class="las la-long-arrow-alt-right"></i></button>',
            });

            $('.prompt-details__gallery').slick({
                slidesToShow: 5,
                slidesToScroll: 1,
                asNavFor: '.prompt-details__thumb',
                dots: false,
                arrows: false,
                focusOnSelect: true,
                prevArrow: '<button type="button" class="slick-prev gig-details-arrow"><i class="las la-long-arrow-alt-left"></i></button>',
                nextArrow: '<button type="button" class="slick-next gig-details-arrow"><i class="las la-long-arrow-alt-right"></i></button>',
                responsive: [{
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: 5,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 991,
                        settings: {
                            slidesToShow: 5,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 5,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 676,
                        settings: {
                            slidesToShow: 4,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 460,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 1
                        }
                    },
                ]
            });

            var nextPage = `<?php echo e($reviews->nextPageUrl()); ?>`;


            $(document).on('click', ".load-more button", function() {
                $('.load-more button').prop('disabled', true)
                if (nextPage) {
                    $.ajax({
                        url: nextPage,
                        method: "GET",
                        data: {},
                        success: function(data) {
                            $('.comment-list').append(data.view)
                            if (data.nextPageUrl) {
                                nextPage = data.nextPageUrl;
                                $('.load-more button').prop('disabled', false)
                            } else {
                                $('.load-more button').remove()
                            }
                        }
                    });
                }

            });

        })(jQuery)
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'partials.wishlist-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .wishlist-btn {
            font-size: 1.5rem;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_8_2\htdocs\PromptLab\Files\core\resources\views/templates/basic/prompt/details.blade.php ENDPATH**/ ?>