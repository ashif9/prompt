<?php
    $stepContent = getContent('prompt_step_content.content', true);
?>


<?php $__env->startSection('content'); ?>
    <div class="step-area pb-60">
        <div class="container">
            <div class="prompt-step-content">
                <div class="prompt-complete-card text-center">

                    <div class="d-flex gap-3 justify-content-center align-items-center">

                        <h4 class="prompt-complete-card__title text-center">
                            <i class="las la-check-circle"></i> <?php echo app('translator')->get('Congratulations!'); ?>
                            <br>
                            <?php if(session('EDIT_PROMPT')): ?>
                                <?php echo app('translator')->get('Your prompt has been successfully updated.'); ?>
                            <?php else: ?>
                                <?php echo app('translator')->get('Your prompt has been successfully created.'); ?>
                            <?php endif; ?>
                        </h4>
                    </div>

                    <p class="subtitle text-center">
                        <?php if(gs('prompt_approval')): ?>
                            <?php echo app('translator')->get('Great job! Your prompt is now published for everyone to explore.'); ?>
                        <?php else: ?>
                            <?php echo app('translator')->get('Thank you! Our team will review it shortly to ensure everything looks great. Stay tuned for updates.'); ?>
                        <?php endif; ?>
                    </p>

                    <a href="<?php echo e(route('user.prompt.my.list')); ?>" class="btn btn--base btn--lg mt-5"><?php echo app('translator')->get('View Your Prompts'); ?></a>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_8_2\htdocs\PromptLab\Files\core\resources\views/templates/basic/user/prompt/step4.blade.php ENDPATH**/ ?>