<?php $__env->startSection('panel'); ?>
    <div class="row gy-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#basic-details" type="button"><?php echo app('translator')->get('Basic Details'); ?></button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#description" type="button"><?php echo app('translator')->get('Description'); ?></button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#prompt" type="button"><?php echo app('translator')->get('Prompt'); ?></button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#testing-prompt" type="button"><?php echo app('translator')->get('Testing Prompt'); ?></button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#instruction" type="button"><?php echo app('translator')->get('Instruction'); ?></button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#media-content" type="button"><?php echo app('translator')->get('Media Content'); ?></button>
                        </li>
                    </ul>

                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="basic-details">
                            <div class="mt-4">
                                <ul class="list-group list-group-flush">


                                    <li class="list-group-item">
                                        <span class="text--muted"><?php echo app('translator')->get('Status'); ?></span>
                                        <?php echo $prompt->promptStatusBadge ?>
                                    </li>

                                    <li class="list-group-item">
                                        <span class="text--muted"><?php echo app('translator')->get('Prompt Owner'); ?></span>
                                        <h6 class="text--primary"><a href="<?php echo e(route('admin.users.detail', $prompt->user_id)); ?>"><?php echo e($prompt->user->username); ?></a>
                                        </h6>
                                    </li>
                                    <li class="list-group-item">
                                        <span class="text--muted"><?php echo app('translator')->get('Title'); ?></span>
                                        <h6><?php echo e(__($prompt->title)); ?></h6>
                                    </li>
                                    <li class="list-group-item">
                                        <span class="text--muted"><?php echo app('translator')->get('Price'); ?></span>
                                        <h6><?php echo e(showAmount($prompt->price)); ?></h6>
                                    </li>

                                    <li class="list-group-item">
                                        <span class="text--muted"><?php echo app('translator')->get('Sale'); ?></span>
                                        <h6><?php echo e(__($prompt->sales_count)); ?></h6>
                                    </li>

                                    <li class="list-group-item">
                                        <span class="text--muted"><?php echo app('translator')->get('View'); ?></span>
                                        <h6><?php echo e(__($prompt->views)); ?></h6>
                                    </li>

                                    <li class="list-group-item">
                                        <span class="text--muted"><?php echo app('translator')->get('Category'); ?></span>
                                        <h6><?php echo e(__($prompt->category->name)); ?></h6>
                                    </li>
                                    <li class="list-group-item">
                                        <span class="text--muted"><?php echo app('translator')->get('AI Tool'); ?></span>
                                        <h6><?php echo e(__($prompt->tool->name)); ?> <?php if($prompt->tool_version_id): ?>
                                                (<?php echo e(__($prompt->toolVersion->name ?? '')); ?>)
                                            <?php endif; ?>
                                        </h6>
                                    </li>

                                    <?php if($prompt->tags): ?>
                                        <li class="list-group-item">
                                            <span><?php echo app('translator')->get('Tags'); ?></span>

                                            <div>
                                                <?php $__currentLoopData = $prompt->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge badge--primary"><?php echo e($tags); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </div>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="description">
                            <div class="mt-4">
                                <?php echo $prompt->description; ?>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="prompt">
                            <div class="mt-4">
                                <?php echo $prompt->prompt; ?>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="testing-prompt">
                            <div class="mt-4">
                                <?php echo $prompt->testing_details; ?>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="instruction">
                            <div class="mt-4">
                                <?php echo $prompt->instruction; ?>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="media-content">
                            <div class="mt-4">
                                <div class="row gy-4">
                                    <?php $__currentLoopData = $allImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3">
                                            <div class="gallery-card">
                                                <a class="view-btn" data-rel="lightcase:myCollection" href="<?php echo e(getImage(getFilePath('prompt') . '/' . $image, getFileSize('prompt'))); ?>">
                                                    <i class="las la-image"></i></a>
                                                <img class="w-100" src="<?php echo e(getImage(getFilePath('prompt') . '/' . 'thumb_' . $image)); ?>" alt="image">
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginalbd5922df145d522b37bf664b524be380 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbd5922df145d522b37bf664b524be380 = $attributes; } ?>
<?php $component = App\View\Components\ConfirmationModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ConfirmationModal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbd5922df145d522b37bf664b524be380)): ?>
<?php $attributes = $__attributesOriginalbd5922df145d522b37bf664b524be380; ?>
<?php unset($__attributesOriginalbd5922df145d522b37bf664b524be380); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd5922df145d522b37bf664b524be380)): ?>
<?php $component = $__componentOriginalbd5922df145d522b37bf664b524be380; ?>
<?php unset($__componentOriginalbd5922df145d522b37bf664b524be380); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <?php if($prompt->status == Status::PROMPT_PENDING || $prompt->status == Status::PROMPT_APPROVED): ?>
        <button class="btn btn-outline--danger confirmationBtn" data-action="<?php echo e(route('admin.prompt.reject', $prompt->id)); ?>" data-question="<?php echo app('translator')->get('Are you sure to reject this prompt'); ?>?" type="button">
            <i class="la la-times"></i> <?php echo app('translator')->get('Reject'); ?>
        </button>
    <?php endif; ?>
    <?php if($prompt->status == Status::PROMPT_REJECTED || $prompt->status == Status::PROMPT_PENDING): ?>
        <button class="btn btn-outline--success confirmationBtn" data-action="<?php echo e(route('admin.prompt.approve', $prompt->id)); ?>" data-question="<?php echo app('translator')->get('Are you sure to approve this prompt'); ?>?" type="button">
            <i class="la la-check"></i> <?php echo app('translator')->get('Approve'); ?>
        </button>
    <?php endif; ?>

    <?php if($prompt->status !== Status::PROMPT_REJECTED): ?>
        <?php if($prompt->is_featured == Status::PROMPT_FEATURED): ?>
            <button class="btn btn-outline--warning confirmationBtn" data-question="<?php echo app('translator')->get('Are you sure to unfeature this prompt?'); ?>" data-action="<?php echo e(route('admin.prompt.feature', $prompt->id)); ?>" type="button">
                <i class="la la-times"></i> <?php echo app('translator')->get('Unfeatured'); ?>
            </button>
        <?php else: ?>
            <button class="btn btn-outline--success confirmationBtn" data-question="<?php echo app('translator')->get('Are you sure to feature this prompt?'); ?>" data-action="<?php echo e(route('admin.prompt.feature', $prompt->id)); ?>" type="button">
                <i class="la la-check"></i> <?php echo app('translator')->get('Featured'); ?>
            </button>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link href="<?php echo e(asset('assets/admin/css/vendor/lightcase.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('assets/admin/js/vendor/lightcase.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .list-group-item {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            padding: .8rem 0;
            border: 1px solid #f1f1f1;
        }

        .accordion-button:not(.collapsed) {
            box-shadow: none !important;
        }

        .gallery-card {
            position: relative;
        }

        .gallery-card:hover .view-btn {
            opacity: 1;
            visibility: visible;
        }

        .gallery-card .view-btn {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.364);
            color: #f0e9e9;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            font-size: 42px;
            opacity: 0;
            visibility: none;
            -webkit-transition: all 0.3s;
            -o-transition: all 0.3s;
            transition: all 0.3s;
        }

        .thumb i {
            font-size: 22px;
        }

        .lightcase-icon-prev:before {
            content: '\f104' !important;
            font-family: 'Line Awesome Free' !important;
            font-weight: 900 !important;
        }

        .lightcase-icon-next:before {
            content: '\f105' !important;
            font-family: 'Line Awesome Free' !important;
            font-weight: 900 !important;
        }

        .lightcase-icon-close:before {
            content: '\f00d' !important;
            font-family: 'Line Awesome Free' !important;
            font-weight: 900 !important;
        }

        .lightcase-icon-prev,
        .lightcase-icon-next,
        .lightcase-icon-close {
            border: 1px solid #ddd;
            font-size: 22px !important;
            width: 50px !important;
            height: 50px !important;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            background-color: #ffffff0f;
        }

        hr {
            border-color: #b7b7b7 !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        $('a[data-rel^=lightcase]').lightcase();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_8_2\htdocs\PromptLab\Files\core\resources\views/admin/prompt/details.blade.php ENDPATH**/ ?>