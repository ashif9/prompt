<?php $__env->startSection('content'); ?>

    <?php
        $bannerContent = getContent('banner.content', true);
    ?>

    <section class="banner-section">
        <div class="container">
            <div class="row align-items-center gy-4">
                <div class="col-lg-6">
                    <div class="banner-content">
                        <h1 class="banner-content__title"><?php echo e(__(@$bannerContent->data_values->heading)); ?></h1>
                        <p class="banner-content__desc"><?php echo e(__(@$bannerContent->data_values->subheading)); ?>

                            <span class="text--gradient"> <?php echo e(__(@$bannerContent->data_values->highlight_subheading)); ?></span>
                        </p>
                        <div class="banner-content__btn">
                            <a href="<?php echo e(@$bannerContent->data_values->left_button_link); ?>" class="btn btn--base"><?php echo e(__(@$bannerContent->data_values->left_button_name)); ?></a>
                            <a href="<?php echo e(@$bannerContent->data_values->right_button_link); ?>" class="btn btn-outline--base"><?php echo e(__(@$bannerContent->data_values->right_button_name)); ?></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="banner-right__thumb">
                        <img src="<?php echo e(frontendImage('banner', @$bannerContent->data_values->image,'635x440')); ?>" alt="image">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if(@$sections->secs != null): ?>
        <?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make($activeTemplate . 'sections.' . $sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_8_2\htdocs\PromptLab\Files\core\resources\views/templates/basic/home.blade.php ENDPATH**/ ?>