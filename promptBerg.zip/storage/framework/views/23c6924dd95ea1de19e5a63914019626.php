<?php $__env->startSection('panel'); ?>
    <?php echo $__env->make($activeTemplate . 'partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="common-body">
        <div class="container">
            <div class="d-flex gap-4">
                <?php echo $__env->make($activeTemplate . 'partials.user_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="dashboard-main-content">
                    <div class="dashboard-heading mb-4 d-xl-none d-block">
                        <div class="dashboard-body__bar">
                            <button type="button" class="dashboard-body__bar-icon"><i class="las la-bars"></i></button>
                        </div>
                    </div>

                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </main>
    <?php echo $__env->make($activeTemplate . 'partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_8_2\htdocs\PromptLab\Files\core\resources\views/templates/basic/layouts/master.blade.php ENDPATH**/ ?>