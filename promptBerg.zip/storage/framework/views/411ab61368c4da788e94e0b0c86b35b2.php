<?php
    $footerContent = getContent('footer.content', true);
    $socialIcons = getContent('social_icon.element', false, null, true);
    $policyPages = getContent('policy_pages.element', false, null, true);
    $subscribeContent = getContent('subscribe.content', true);
    $pages = App\Models\Page::where('tempname', $activeTemplate)
        ->where('is_default', Status::NO)
        ->latest()
        ->get();
?>
<footer class="footer-area">
    <img src="<?php echo e(frontendImage('footer', @$footerContent->data_values->left_background_image, '210x180')); ?>"
        class="footer-shape" alt="img">

    <img src="<?php echo e(frontendImage('footer', @$footerContent->data_values->right_background_image, '172x125')); ?>"
        class="footer-shape-two" alt="img">

    <div class="pb-60 pt-60">
        <div class="container">
            <div class="row justify-content-center gy-5">
                <div class="col-xl-3 col-sm-6 col-xsm-6">
                    <div class="footer-item">
                        <div class="footer-item__logo">
                            <a href="<?php echo e(route('home')); ?>"> <img src="<?php echo e(siteLogo()); ?>" alt="logo"></a>
                        </div>
                        <p class="footer-item__desc">
                            <?php echo e(__(@$footerContent->data_values->footer_text)); ?></p>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 col-xsm-6">
                    <div class="footer-item pl-lg-70">
                        <h5 class="footer-item__title"><?php echo app('translator')->get('Pages'); ?></h5>
                        <ul class="footer-menu">
                            <?php if(@$pages): ?>
                                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="footer-menu__item"><a href="<?php echo e(route('pages', [$data->slug])); ?>"
                                            class="footer-menu__link"><?php echo e(__($data->name)); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <li class="footer-menu__item"><a href="<?php echo e(route('prompt.all')); ?>"
                                    class="footer-menu__link"><?php echo app('translator')->get('Prompts'); ?></a>
                            </li>


                            <li class="footer-menu__item"><a href="<?php echo e(route('blog')); ?>" class="footer-menu__link"><?php echo app('translator')->get('Blogs'); ?></a>
                            </li>
                            <li class="footer-menu__item"><a href="<?php echo e(route('contact')); ?>" class="footer-menu__link"><?php echo app('translator')->get('Contact Us'); ?></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 col-sm-6 col-xsm-6">
                    <div class="footer-item">
                        <h5 class="footer-item__title"><?php echo app('translator')->get('Follow Us'); ?></h5>
                        <ul class="footer-menu footer-contact-icon">
                            <?php $__currentLoopData = $socialIcons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="footer-menu__item"><a href="<?php echo e(@$social->data_values->url); ?>"
                                        target="_blank" class="footer-menu__link"> <?php echo @$social->data_values->social_icon; ?>
                                        <?php echo e(@$social->data_values->title); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-4 col-sm-6 col-xsm-6">
                    <div class="footer-item">
                        <h5 class="footer-item__title"><?php echo e(__(@$subscribeContent->data_values->section_title)); ?></h5>
                        <p class="footer-item__desc mb-2"><?php echo e(__(@$subscribeContent->data_values->heading)); ?></p>
                        <div class="cta-form">
                            <form class="cta__subscribe" id="subscribeForm">
                                <?php echo csrf_field(); ?>
                                <div class="input-group form-group gap-2">
                                    <div class="border-gradient subscribe-input">
                                        <input type="email" class="form-control form--control border-gradient w-100"
                                            placeholder="<?php echo app('translator')->get('Enter your email'); ?>" name="email">
                                    </div>
                                    <button class="btn btn--base border--5"><?php echo app('translator')->get('Subscribe'); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <!-- bottom Footer -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row gy-3">
                    <div class="col-lg-6">
                        <p class="fs-14 text-lg-start text-center text--black">&copy; <?php echo e(date('Y')); ?> <a
                                class="text--base" href="<?php echo e(route('home')); ?>"><?php echo e(__(gs()->site_name)); ?>.</a>
                            <?php echo app('translator')->get('All rights reserved.'); ?>
                        </p>
                    </div>
                    <div class="col-lg-6">
                        <div class="footer-bottom__menu justify-content-md-center">
                            <ul>
                                <?php $__currentLoopData = $policyPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a
                                            href="<?php echo e(route('policy.pages', $link->slug)); ?>"><?php echo e(__(@$link->data_values->title)); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Top End-->
</footer>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        (function($) {
            var form = $("#subscribeForm");
            form.on('submit', function(e) {
                e.preventDefault();
                var data = form.serialize();
                $.ajax({
                    url: `<?php echo e(route('subscribe')); ?>`,
                    method: 'post',
                    data: data,
                    success: function(response) {
                        if (response.success) {
                            form.find('input[name=email]').val('');
                            form.find('button[type=submit]').attr('disabled', false);
                            notify('success', response.message);
                        } else {
                            notify('error', response.error);
                        }
                    }
                });
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\xampp_8_2\htdocs\PromptLab\Files\core\resources\views/templates/basic/partials/footer.blade.php ENDPATH**/ ?>