<?php $__env->startSection('content'); ?>
    <div class="row gy-4 justify-content-center">
        <div class="col-12">
            <div class="d-flex flex-wrap gap-3 justify-content-between align-items-center">
                <h6 class="mb-0"><?php echo app('translator')->get('Order Details'); ?></h6>
                <a class="btn btn--sm btn--base" href="<?php echo e(route('user.purchase.history')); ?>"><i class="las la-undo"></i> <?php echo app('translator')->get('Back'); ?></a>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card custom--card">
                <div class="card-body">
                    <div class="row gy-4">
                        <div class="col-md-6">
                            <ul class="list-group text-center withdrawal-list">
                                <li class="list-group-item d-flex justify-content-between">
                                    <span><?php echo app('translator')->get('Order No'); ?></span>
                                    <span><?php echo e($order->order_no); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span><?php echo app('translator')->get('Total Price'); ?></span>
                                    <span><?php echo e(showAmount(@$order->total)); ?></span>
                                </li>

                                <?php if($order->payment): ?>
                                    <li class="list-group-item d-flex justify-content-between">
                                        <span><?php echo app('translator')->get('Payment Trx'); ?></span>
                                        <span><?php echo e($order->payment->trx); ?></span>
                                    </li>
                                <?php endif; ?>

                                <li class="list-group-item d-flex justify-content-between">
                                    <span><?php echo app('translator')->get('Order Date'); ?></span>
                                    <span><?php echo e(showDateTime($order->created_at)); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span><?php echo app('translator')->get('Order Status'); ?></span>
                                    <?php
                                        echo $order->statusBadge;
                                    ?>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <ul class="list-group text-center withdrawal-list">
                                <li class="list-group-item d-flex justify-content-between">
                                    <span><?php echo app('translator')->get('Subtotal'); ?></span>
                                    <span><?php echo e(showAmount(@$order->subtotal)); ?></span>
                                </li>

                                <li class="list-group-item d-flex justify-content-between">
                                    <span><?php echo app('translator')->get('Discount'); ?></span>
                                    <span><?php echo e(showAmount(@$order->discount)); ?></span>
                                </li>

                                <?php if(@$order->payment->trx): ?>
                                    <li class="list-group-item d-flex justify-content-between">
                                        <span><?php echo app('translator')->get('Payment Processing Charge'); ?></span>
                                        <span><?php echo e(showAmount(@$order->payment->charge)); ?></span>
                                    </li>
                                <?php endif; ?>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span><?php echo app('translator')->get('Total Paid'); ?></span>
                                    <span><?php echo e(showAmount(@$order->total + @$order->payment->charge)); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span><?php echo app('translator')->get('Payment Status'); ?></span>
                                    <?php
                                        echo $order->paymentStatusBadge;
                                    ?>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card custom--card">
                <div class="card-body table-responsive p-0">
                    <table class="table table--responsive--xl">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Prompt Title'); ?></th>
                                <th><?php echo app('translator')->get('Tool'); ?></th>
                                <th><?php echo app('translator')->get('Category'); ?></th>
                                <th><?php echo app('translator')->get('Price'); ?></th>
                                <?php if($order->status == Status::ORDER_COMPLETED): ?>
                                    <th><?php echo app('translator')->get('Action'); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="customer">
                                            <div class="customer__thumb">
                                                <a href="<?php echo e(route('prompt.details', $detail->prompt->slug)); ?>"><img src="<?php echo e(getImage(getFilePath('prompt') . '/' . 'thumb_' . @$detail->prompt->image)); ?>" alt="image"></a>
                                            </div>
                                            <div class="customer__content">
                                                <h4 class="customer__name">
                                                    <a href="<?php echo e(route('prompt.details', $detail->prompt->slug)); ?>"><?php echo e(__(@$detail->prompt->title)); ?></a>
                                                </h4>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge-tag style-three">
                                            <i class="fa-solid fa-wand-sparkles"></i>
                                            <span class="text-white"><?php echo e(__(@$detail->prompt->tool->name)); ?></span>
                                        </span>
                                    </td>
                                    <td>
                                        <?php echo e(__(@$detail->prompt->category->name)); ?>

                                    </td>
                                    <td>
                                        <strong><?php echo e(showAmount($detail->price)); ?></strong>
                                    </td>
                                    <?php if($order->status == Status::ORDER_COMPLETED): ?>
                                        <td>
                                            <div class="d-flex gap-2 flex-wrap align-items-center justify-content-end">
                                                <a class="text--base" href="<?php echo e(route('user.prompt.download', $detail->prompt->slug)); ?>">
                                                    <i class="fas fa-download"></i>
                                                </a>

                                                <button class="btn ms-2 btn--warning btn--sm reviewBtn" data-resource="<?php echo e(@$detail->review); ?>" data-action="<?php echo e(route('user.prompt.review', $detail->prompt->slug)); ?>"><i class="las la-star-of-david"></i>
                                                    <?php echo app('translator')->get('Review'); ?></button>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php echo $__env->make($activeTemplate . 'partials.empty', [
                                    'message' => 'No data found',
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal custom--modal fade" id="reviewModal" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="staticBackdropLabel" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Prompt Review'); ?></h5>
                    <span class="close" data-bs-dismiss="modal" type="button" aria-label="Close">
                        <i class="las la-times"></i>
                    </span>
                </div>
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label><?php echo app('translator')->get('Your Ratings'); ?> :</label>
                            <div class="rating">
                                <div class="rating-form-group">
                                    <label class="star-label">
                                        <input name="rating" type="radio" value="1" />
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                    </label>
                                    <label class="star-label">
                                        <input name="rating" type="radio" value="2" />
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                    </label>
                                    <label class="star-label">
                                        <input name="rating" type="radio" value="3" />
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                    </label>
                                    <label class="star-label">
                                        <input name="rating" type="radio" value="4" />
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                    </label>
                                    <label class="star-label">
                                        <input name="rating" type="radio" value="5" />
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                        <span class="icon fs-26"><i class="las la-star"></i></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="mb-3"><?php echo app('translator')->get('Write your opinion'); ?></label>
                            <textarea class="from-control form--control" name="review" rows="5" required></textarea>
                        </div>
                        <button class="btn btn--sm btn--base w-100 submitButton" type="submit"><?php echo app('translator')->get('Submit'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        $('.reviewBtn').on('click', function() {
            var reviewModal = $('#reviewModal');
            var resource = $(this).data('resource');
            var action = $(this).data('action');
            reviewModal.find('form').attr('action', action);
            if (resource.rating) {
                reviewModal.find(`[name="rating"][value="${resource.rating}"]`).prop('checked', true);
            } else {
                reviewModal.find(`[name="rating"]`).prop('checked', false);
            }

            reviewModal.find('[name="review"]').val(resource.review || '');

            reviewModal.modal('show');
        });

        $('form').on('submit', function(e) {
            if ($('[name=rating]:checked').val() == undefined) {
                iziToast.error({
                    message: 'Rating is required',
                    position: "topRight"
                });
                e.preventDefault();
                return;
            }
            $(this).submit();

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate . 'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_8_2\htdocs\PromptLab\Files\core\resources\views/templates/basic/user/order/detail.blade.php ENDPATH**/ ?>