<div class="breadcrumb">
    <div class="container">
        <div class="breadcrumb__wrapper">
            <ul class="breadcrumb__list">
                <li class="breadcrumb__item"><a href="{{ route('home') }}" class="breadcrumb__link"> <i class="las la-home"></i>
                        @lang('Home')</a> </li>
                <li class="breadcrumb__item">/</li>
                <li class="breadcrumb__item"> <span class="breadcrumb__item-text"> {{ __($pageTitle) }} </span> </li>
            </ul>
        </div>
    </div>
</div>
