<div class="card-empty">
    <div class="empty-thumb">
        <img src="{{ asset('assets/images/empty_list.png') }}" alt="image">
    </div>
    <p class="text-center">{{ __($message) }}</p>
</div>
