<?php

return [
    'prompt.all'=>false,
    'prompt.details'=>false,
    'seller.profile'=>false
];
